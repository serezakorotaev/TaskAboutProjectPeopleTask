create unique index TASK_ID_UINDEX
    on TASK (ID);

