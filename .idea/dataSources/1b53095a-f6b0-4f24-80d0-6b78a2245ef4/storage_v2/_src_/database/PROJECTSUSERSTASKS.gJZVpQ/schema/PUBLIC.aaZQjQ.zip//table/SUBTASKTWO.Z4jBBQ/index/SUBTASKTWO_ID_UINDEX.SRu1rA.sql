create unique index SUBTASKTWO_ID_UINDEX
    on SUBTASKTWO (ID);

