create unique index PROJECT_ID_UINDEX
    on PROJECT (ID);

