create unique index USERS_ID_UINDEX
    on USERS (ID);

