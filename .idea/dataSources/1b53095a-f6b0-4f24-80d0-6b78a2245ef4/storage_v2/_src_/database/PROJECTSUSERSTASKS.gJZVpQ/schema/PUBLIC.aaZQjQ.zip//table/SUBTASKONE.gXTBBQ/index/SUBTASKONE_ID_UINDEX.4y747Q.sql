create unique index SUBTASKONE_ID_UINDEX
    on SUBTASKONE (ID);

